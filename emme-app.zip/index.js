// index.js (root del proyecto)
import 'expo-router/entry'
