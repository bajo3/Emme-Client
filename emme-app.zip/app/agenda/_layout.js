// app/agenda/_layout.js
import { Stack } from 'expo-router'

export default function AgendaLayout() {
  return <Stack screenOptions={{ headerShown: false }} />
}